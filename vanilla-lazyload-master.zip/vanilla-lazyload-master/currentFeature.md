# Current feature:

- Unobserve all elements on `loadAll()`. It's better for performance. It solves #469.
- Added some hidden images in the `load_all.html` demo
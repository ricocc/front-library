export const SRC = "src";
export const SRCSET = "srcset";
export const SIZES = "sizes";
export const POSTER = "poster";
export const ORIGINALS = "llOriginalAttrs";
export const DATA = "data";